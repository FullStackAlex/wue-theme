<?php

get_template_part( "inc/custom-endpoints/frontpage" );
