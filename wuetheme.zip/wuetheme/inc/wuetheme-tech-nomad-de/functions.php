<?php


add_filter( "pre_http_request", "wp_rocket_custom_hook", 1, 3 );
function wp_rocket_custom_hook( $false, $args, $url ) {

	if ( strpos( $url, 'wp-rocket.me' ) !== false ) {
		$bla = array(
			"body"          => "",
			"cookies"       => array(),
			"headers"       => array(),
			"http_response" => null,
			"response"      => array(
				"code"    => false,
				"message" => false
			)
		);

		return $bla;
	}

	return false;
}


add_action( "wp_footer", function () {
	?>

    <!-- Matomo -->


    <script type="text/javascript">
        var _paq = _paq || [];
        /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
        _paq.push(["setDocumentTitle", document.domain + "/" + document.title]);
        _paq.push(['trackPageView']);
        _paq.push(['enableLinkTracking']);
        _paq.push(["enableHeartBeatTimer"]);

        (function () {
            var u = "//www.matomo.tech-nomad.de/";
            _paq.push(['setTrackerUrl', u + 'piwik.php']);
            _paq.push(['setSiteId', '3']);
            _paq.push(['addTracker', piwikUrl = u+'piwik.php', 1]);
            var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
            g.type = 'text/javascript';
            g.async = true;
            g.defer = true;
            g.src = u + 'piwik.js';
            s.parentNode.insertBefore(g, s);
        })();
    </script>
	<?php
}, 1000 );



function deactivate_plugin_conditional() {
	if ( is_plugin_active('wp-rocket/wp-rocket.php') && $_SERVER["HTTP_HOST"] === "dev.wue-theme") {
		deactivate_plugins( "wp-rocket/wp-rocket.php" );
	}
}
add_action( 'admin_init', 'deactivate_plugin_conditional' );
