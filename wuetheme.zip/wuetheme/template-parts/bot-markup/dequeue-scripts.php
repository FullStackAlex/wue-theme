<?php
wp_dequeue_script( "technomad-app-bundle" );
wp_deregister_script( "technomad-app-bundle" );
wp_dequeue_script( "babel-polyfill-bundle" );
wp_deregister_script( "babel-polyfill-bundle" );