<style>
	article, p, a{
		margin-bottom: 1rem;
	}
    h1, h2, h3, h4, h5, h6{
        margin-bottom: 2rem;
    }
    nav li a{
        display: block;
    }

    .button, button{
        margin: 2rem 0;
    }
	body>header,
	body>footer,
	main{
		padding: 1rem;
		box-sizing: border-box;
		width: 100%;
	}
</style>